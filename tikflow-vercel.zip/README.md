# TikFlow - TikTok Video & MP3 Downloader (Vercel Ready)

Fast, modern TikTok video, audio, and photo downloader without watermark powered by the TikWM API engine. Includes 7 aesthetic themes, 50+ viral Google Fonts, and 100% Google AdSense-compliant pages.

## 🚀 How to Deploy on Vercel

### Method 1: Deploy with GitHub (Recommended)
1. Extract or upload this project to a new repository on your GitHub account.
2. Go to [vercel.com](https://vercel.com) and log in.
3. Click **"Add New..."** → **"Project"**.
4. Import your GitHub repository.
5. In the project settings, keep default settings (Framework: *Other*).
6. Click **Deploy**!
7. Your site is live on your custom `.vercel.app` domain within 30 seconds!

### Method 2: Deploy with Vercel CLI
```bash
npm install -g vercel
cd tiktok-downloader
vercel
```

### Method 3: Run Locally
```bash
node server.js
# Or
pnpm start
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## 🌟 Included Features & Pages
- **TikTok Downloader:**
  - Full HD MP4 Video without watermark
  - TikTok MP3 audio sound extractor
  - TikTok photo carousel / slideshow album downloader
  - In-page video preview player
  - Local device download history
- **Theme & Typography Studio:**
  - 7 Aesthetic Themes (Cyber Neon, Clean Snow Light, Midnight AMOLED, Ocean Breeze, Emerald Matrix, Sunset Amber, Synthwave 80s)
  - 50+ Viral Google Fonts on-demand loader with live search & categories
- **Google AdSense Ready Pages (100% Compliant):**
  - Privacy Policy (`/privacy-policy`)
  - Terms of Service (`/terms-of-service`)
  - About Us (`/about`)
  - Contact Us (`/contact`)
  - DMCA & Copyright Policy (`/dmca`)
  - Help & FAQ (`/faq`)
  - How to Download Guide (`/how-to-download`)
- **Clean Structure:**
  - Zero advertisement banners or empty ad spaces (as requested)
  - Ultra-responsive mobile & desktop layout
