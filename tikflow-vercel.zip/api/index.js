// Vercel Serverless Function Handler for TikFlow API

const setCorsHeaders = (res) => {
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT');
  res.setHeader(
    'Access-Control-Allow-Headers',
    'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version'
  );
};

export default async function handler(req, res) {
  setCorsHeaders(res);

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const urlObj = new URL(req.url, `https://${req.headers.host || 'localhost'}`);
  const pathname = urlObj.pathname;

  // Handle Download Stream Proxy
  if (pathname.includes('/download') || req.query.action === 'download') {
    const targetUrl = req.query.url;
    const fileName = req.query.filename || 'tiktok_download';

    if (!targetUrl) {
      return res.status(400).send('Target URL is required.');
    }

    try {
      const upstreamRes = await fetch(targetUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
          'Referer': 'https://www.tiktok.com/'
        }
      });

      if (!upstreamRes.ok) {
        return res.status(upstreamRes.status).send('Failed to fetch media from CDN.');
      }

      const safeName = fileName.replace(/[^a-zA-Z0-9_\-\.]/g, '_');
      const contentType = upstreamRes.headers.get('content-type') || 'application/octet-stream';
      const contentLength = upstreamRes.headers.get('content-length');

      res.setHeader('Content-Type', contentType);
      res.setHeader('Content-Disposition', `attachment; filename="${safeName}"`);
      if (contentLength) res.setHeader('Content-Length', contentLength);

      const arrayBuffer = await upstreamRes.arrayBuffer();
      return res.status(200).send(Buffer.from(arrayBuffer));
    } catch (err) {
      console.error('Download stream error:', err);
      return res.status(500).send('Error streaming download.');
    }
  }

  // Handle Contact Form
  if (pathname.includes('/contact') || req.query.action === 'contact') {
    return res.status(200).json({
      success: true,
      message: 'Thank you! Your message has been received. Our team will review it within 24-48 hours.'
    });
  }

  // Handle Video Analysis (Default API action)
  const targetUrl = req.query.url || req.body?.url;

  if (!targetUrl || typeof targetUrl !== 'string') {
    return res.status(400).json({
      success: false,
      message: 'Please provide a valid TikTok video URL.'
    });
  }

  const cleanUrl = targetUrl.trim();
  const tiktokRegex = /(tiktok\.com|douyin\.com)/i;
  if (!tiktokRegex.test(cleanUrl)) {
    return res.status(400).json({
      success: false,
      message: 'Invalid link. Please paste a valid TikTok link.'
    });
  }

  try {
    const apiUrl = `https://www.tikwm.com/api/?url=${encodeURIComponent(cleanUrl)}&count=12&cursor=0&web=1&hd=1`;
    const response = await fetch(apiUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        'Accept': 'application/json'
      }
    });

    if (!response.ok) {
      return res.status(502).json({
        success: false,
        message: 'TikWM service responded with an error. Please try again in a few moments.'
      });
    }

    const data = await response.json();

    if (data.code !== 0 || !data.data) {
      return res.status(422).json({
        success: false,
        message: data.msg || 'Unable to fetch video. The video might be private or restricted.'
      });
    }

    const item = data.data;

    const formatUrl = (u) => {
      if (!u) return null;
      if (u.startsWith('//')) return `https:${u}`;
      if (u.startsWith('/')) return `https://www.tikwm.com${u}`;
      return u;
    };

    const result = {
      success: true,
      id: item.id,
      title: item.title || 'TikTok Video',
      duration: item.duration || 0,
      cover: formatUrl(item.cover) || formatUrl(item.origin_cover),
      author: {
        uniqueId: item.author?.unique_id || 'tiktok_user',
        nickname: item.author?.nickname || 'TikTok Creator',
        avatar: formatUrl(item.author?.avatar)
      },
      stats: {
        playCount: item.play_count || 0,
        diggCount: item.digg_count || 0,
        commentCount: item.comment_count || 0,
        shareCount: item.share_count || 0
      },
      downloads: {
        noWatermark: formatUrl(item.play),
        watermark: formatUrl(item.wmplay),
        hd: formatUrl(item.hdplay),
        music: formatUrl(item.music),
        musicInfo: {
          title: item.music_info?.title || 'Original Sound',
          author: item.music_info?.author || ''
        }
      },
      images: Array.isArray(item.images) ? item.images.map(img => formatUrl(img)) : null,
      isImageAlbum: Array.isArray(item.images) && item.images.length > 0
    };

    return res.status(200).json(result);
  } catch (error) {
    console.error('Error analyzing TikTok video:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to process request. Please try again.'
    });
  }
}
