// Theme & UI utilities for TikFlow

const THEMES = [
  { id: 'cyber-neon', name: 'Cyber Neon (Default)', type: 'dark', color1: '#00f2fe', color2: '#fe2c55', bg: '#0a0b10' },
  { id: 'clean-light', name: 'Clean Snow Light', type: 'light', color1: '#0072ff', color2: '#fe2c55', bg: '#f8fafc' },
  { id: 'midnight-amoled', name: 'Midnight AMOLED', type: 'dark', color1: '#a855f7', color2: '#8b5cf6', bg: '#000000' },
  { id: 'ocean-breeze', name: 'Ocean Breeze', type: 'dark', color1: '#00f2fe', color2: '#3b82f6', bg: '#0b1329' },
  { id: 'emerald-matrix', name: 'Emerald Matrix', type: 'dark', color1: '#10b981', color2: '#22c55e', bg: '#051b14' },
  { id: 'sunset-amber', name: 'Sunset Amber', type: 'dark', color1: '#f59e0b', color2: '#f43f5e', bg: '#150d0f' },
  { id: 'synthwave-retro', name: 'Synthwave 80s', type: 'dark', color1: '#f43f5e', color2: '#facc15', bg: '#16082b' }
];

function applyTheme(themeId) {
  const selected = THEMES.find(t => t.id === themeId) || THEMES[0];
  document.documentElement.setAttribute('data-theme', selected.id);
  localStorage.setItem('tikflow_theme', selected.id);

  // Update theme swatch active state
  document.querySelectorAll('.theme-picker-card').forEach(card => {
    if (card.dataset.theme === selected.id) {
      card.classList.add('active');
    } else {
      card.classList.remove('active');
    }
  });

  const displayEl = document.getElementById('currentThemeName');
  if (displayEl) displayEl.innerText = selected.name;
}

// Initialize Theme on boot
(function initTheme() {
  const savedTheme = localStorage.getItem('tikflow_theme') || 'cyber-neon';
  applyTheme(savedTheme);
})();

document.addEventListener('DOMContentLoaded', () => {
  // Render theme switcher swatches
  const themeGrid = document.getElementById('themeSwatchesGrid');
  if (themeGrid) {
    const currentTheme = localStorage.getItem('tikflow_theme') || 'cyber-neon';
    themeGrid.innerHTML = '';
    THEMES.forEach(thm => {
      const card = document.createElement('div');
      card.className = `theme-picker-card ${thm.id === currentTheme ? 'active' : ''}`;
      card.dataset.theme = thm.id;
      card.innerHTML = `
        <div class="theme-card-preview" style="background: ${thm.bg}; border: 2px solid ${thm.color1};">
          <div class="theme-preview-dots">
            <span style="background: ${thm.color1};"></span>
            <span style="background: ${thm.color2};"></span>
          </div>
          <span class="theme-check-icon">✓</span>
        </div>
        <div class="theme-card-info">
          <span class="theme-card-title">${thm.name}</span>
          <span class="theme-card-badge">${thm.type.toUpperCase()}</span>
        </div>
      `;
      card.addEventListener('click', () => {
        applyTheme(thm.id);
        showToast(`Theme changed to ${thm.name}`);
      });
      themeGrid.appendChild(card);
    });
  }

  // Customizer Modal Toggle
  const customizerModal = document.getElementById('customizerModal');
  const openCustomizerBtns = document.querySelectorAll('.btn-open-customizer, #themeToggleBtn');
  const closeCustomizerBtn = document.getElementById('closeCustomizerBtn');
  const customizerBackdrop = document.getElementById('customizerBackdrop');

  function openCustomizer(defaultTab = 'themes') {
    if (!customizerModal) return;
    customizerModal.classList.add('open');
    if (customizerBackdrop) customizerBackdrop.classList.add('open');
    switchCustomizerTab(defaultTab);
  }

  function closeCustomizer() {
    if (!customizerModal) return;
    customizerModal.classList.remove('open');
    if (customizerBackdrop) customizerBackdrop.classList.remove('open');
  }

  openCustomizerBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      openCustomizer();
    });
  });

  if (closeCustomizerBtn) closeCustomizerBtn.addEventListener('click', closeCustomizer);
  if (customizerBackdrop) customizerBackdrop.addEventListener('click', closeCustomizer);

  // Customizer Tabs switching
  const tabBtns = document.querySelectorAll('.customizer-tab-btn');
  const tabPanes = document.querySelectorAll('.customizer-tab-pane');

  function switchCustomizerTab(tabName) {
    tabBtns.forEach(btn => {
      if (btn.dataset.tab === tabName) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });

    tabPanes.forEach(pane => {
      if (pane.id === `tab-${tabName}`) {
        pane.classList.add('active');
      } else {
        pane.classList.remove('active');
      }
    });
  }

  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => switchCustomizerTab(btn.dataset.tab));
  });

  // Mobile Menu Drawer
  const mobileToggleBtn = document.getElementById('mobileToggleBtn');
  const mobileDrawer = document.getElementById('mobileNavDrawer');
  if (mobileToggleBtn && mobileDrawer) {
    mobileToggleBtn.addEventListener('click', () => {
      mobileDrawer.classList.toggle('open');
    });
  }

  // FAQ Accordion
  const faqItems = document.querySelectorAll('.faq-item');
  faqItems.forEach(item => {
    const questionBtn = item.querySelector('.faq-question');
    if (questionBtn) {
      questionBtn.addEventListener('click', () => {
        const isOpen = item.classList.contains('open');
        faqItems.forEach(i => i.classList.remove('open'));
        if (!isOpen) {
          item.classList.add('open');
        }
      });
    }
  });

  // Contact Form AJAX Handler
  const contactForm = document.getElementById('contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const submitBtn = contactForm.querySelector('button[type="submit"]');
      const originalText = submitBtn.innerHTML;
      submitBtn.disabled = true;
      submitBtn.innerText = 'Sending message...';

      const formData = {
        name: contactForm.querySelector('#name')?.value,
        email: contactForm.querySelector('#email')?.value,
        subject: contactForm.querySelector('#subject')?.value,
        message: contactForm.querySelector('#message')?.value
      };

      try {
        const res = await fetch('/api/contact', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(formData)
        });
        const result = await res.json();
        if (result.success) {
          showToast(result.message || 'Your message has been sent successfully!');
          contactForm.reset();
        } else {
          showToast(result.message || 'Failed to send message', 'error');
        }
      } catch (err) {
        showToast('Thank you! Your feedback has been noted.', 'info');
        contactForm.reset();
      } finally {
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;
      }
    });
  }
});

// Global Toast Notification Helper
function showToast(message, type = 'info') {
  let container = document.getElementById('toastContainer');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toastContainer';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = 'toast';
  if (type === 'error') {
    toast.style.borderLeftColor = '#fe2c55';
  } else if (type === 'success') {
    toast.style.borderLeftColor = '#10b981';
  }

  toast.innerHTML = `<span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3200);
}

window.showToast = showToast;
window.applyTheme = applyTheme;
