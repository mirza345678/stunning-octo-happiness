// TikFlow - Core TikTok Downloader Application Logic

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('downloaderForm');
  const input = document.getElementById('videoUrlInput');
  const pasteBtn = document.getElementById('pasteBtn');
  const clearBtn = document.getElementById('clearBtn');
  const submitBtn = document.getElementById('submitBtn');
  const loadingIndicator = document.getElementById('loadingIndicator');
  const errorBanner = document.getElementById('errorBanner');
  const errorMessage = document.getElementById('errorMessage');
  const resultSection = document.getElementById('resultSection');
  const resetBtn = document.getElementById('resetBtn');

  // Input Change listener for clear button visibility
  if (input && clearBtn) {
    input.addEventListener('input', () => {
      clearBtn.style.display = input.value.trim().length > 0 ? 'flex' : 'none';
      hideError();
    });
  }

  // Clear Input Action
  if (clearBtn) {
    clearBtn.addEventListener('click', () => {
      input.value = '';
      clearBtn.style.display = 'none';
      input.focus();
    });
  }

  // Paste Action via Clipboard API
  if (pasteBtn && input) {
    pasteBtn.addEventListener('click', async () => {
      try {
        const text = await navigator.clipboard.readText();
        if (text && text.trim()) {
          input.value = text.trim();
          clearBtn.style.display = 'flex';
          window.showToast?.('Link pasted from clipboard!');
          // Auto submit if it looks like a valid tiktok link
          if (/(tiktok\.com|douyin\.com)/i.test(input.value)) {
            triggerAnalyze(input.value);
          }
        } else {
          window.showToast?.('Clipboard is empty or does not contain text.', 'error');
        }
      } catch (err) {
        input.focus();
        window.showToast?.('Please paste link manually (Ctrl+V / Long press).');
      }
    });
  }

  // Form Submit Action
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const url = input.value.trim();
      if (!url) {
        showError('Please enter or paste a valid TikTok video URL.');
        return;
      }
      triggerAnalyze(url);
    });
  }

  // Reset Button Action
  if (resetBtn) {
    resetBtn.addEventListener('click', () => {
      resultSection.classList.remove('active');
      input.value = '';
      clearBtn.style.display = 'none';
      input.focus();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  // Trigger Analysis
  async function triggerAnalyze(tiktokUrl) {
    hideError();
    resultSection.classList.remove('active');
    loadingIndicator.classList.add('active');
    submitBtn.disabled = true;

    try {
      let data = null;

      // 1. Try local server API
      try {
        const response = await fetch(`/api/analyze?url=${encodeURIComponent(tiktokUrl)}`);
        const json = await response.json();
        if (json.success) {
          data = json;
        } else {
          throw new Error(json.message || 'Server error');
        }
      } catch (localErr) {
        console.warn('Local API failed, falling back to direct TikWM API:', localErr);
        // Fallback: direct TikWM client call (TikWM allows CORS)
        const fallbackRes = await fetch(`https://www.tikwm.com/api/?url=${encodeURIComponent(tiktokUrl)}&hd=1`);
        const fallbackJson = await fallbackRes.json();
        if (fallbackJson.code === 0 && fallbackJson.data) {
          data = normalizeTikwmData(fallbackJson.data);
        } else {
          throw new Error(fallbackJson.msg || 'Unable to fetch video details.');
        }
      }

      if (data) {
        renderResult(data);
        saveToHistory(tiktokUrl, data.title, data.cover);
        loadingIndicator.classList.remove('active');
        resultSection.classList.add('active');
        resultSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    } catch (err) {
      console.error(err);
      loadingIndicator.classList.remove('active');
      showError(err.message || 'Failed to download video. Please verify the URL and try again.');
    } finally {
      submitBtn.disabled = false;
    }
  }

  // Helper to normalize direct TikWM output if fallback was used
  function normalizeTikwmData(item) {
    const formatUrl = (u) => {
      if (!u) return null;
      if (u.startsWith('//')) return `https:${u}`;
      if (u.startsWith('/')) return `https://www.tikwm.com${u}`;
      return u;
    };

    return {
      success: true,
      id: item.id,
      title: item.title || 'TikTok Video',
      duration: item.duration || 0,
      cover: formatUrl(item.cover),
      author: {
        uniqueId: item.author?.unique_id || 'tiktok_user',
        nickname: item.author?.nickname || 'TikTok Creator',
        avatar: formatUrl(item.author?.avatar)
      },
      stats: {
        playCount: item.play_count || 0,
        diggCount: item.digg_count || 0,
        commentCount: item.comment_count || 0,
        shareCount: item.share_count || 0
      },
      downloads: {
        noWatermark: formatUrl(item.play),
        watermark: formatUrl(item.wmplay),
        hd: formatUrl(item.hdplay),
        music: formatUrl(item.music),
        musicInfo: {
          title: item.music_info?.title || 'Original Sound',
          author: item.music_info?.author || ''
        }
      },
      images: Array.isArray(item.images) ? item.images.map(img => formatUrl(img)) : null,
      isImageAlbum: Array.isArray(item.images) && item.images.length > 0
    };
  }

  // Render Result UI
  function renderResult(data) {
    // Media column
    const thumbnailImg = document.getElementById('resultThumbnail');
    const durationTag = document.getElementById('resultDuration');
    const previewContainer = document.getElementById('previewContainer');

    if (thumbnailImg) thumbnailImg.src = data.cover || 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg"/>';
    if (durationTag) {
      if (data.duration > 0) {
        durationTag.style.display = 'block';
        durationTag.innerText = formatDuration(data.duration);
      } else {
        durationTag.style.display = 'none';
      }
    }

    // Author info
    const authorAvatar = document.getElementById('resultAvatar');
    const authorNickname = document.getElementById('resultNickname');
    const authorHandle = document.getElementById('resultHandle');
    const videoCaption = document.getElementById('resultCaption');

    if (authorAvatar) authorAvatar.src = data.author?.avatar || '/images/logo.svg';
    if (authorNickname) authorNickname.innerText = data.author?.nickname || 'TikTok User';
    if (authorHandle) authorHandle.innerText = `@${data.author?.uniqueId || 'user'}`;
    if (videoCaption) videoCaption.innerText = data.title || 'No caption provided.';

    // Stats
    const playStat = document.getElementById('statPlays');
    const likeStat = document.getElementById('statLikes');
    const commentStat = document.getElementById('statComments');
    const shareStat = document.getElementById('statShares');

    if (playStat) playStat.innerText = formatNumber(data.stats?.playCount || 0);
    if (likeStat) likeStat.innerText = formatNumber(data.stats?.diggCount || 0);
    if (commentStat) commentStat.innerText = formatNumber(data.stats?.commentCount || 0);
    if (shareStat) shareStat.innerText = formatNumber(data.stats?.shareCount || 0);

    // Download Links
    const safeTitle = (data.title || 'tiktok_video')
      .replace(/[^a-zA-Z0-9]/g, '_')
      .substring(0, 30);

    // Button: No Watermark MP4
    const btnNoWm = document.getElementById('btnDownloadNoWm');
    if (btnNoWm && data.downloads.noWatermark) {
      btnNoWm.href = `/api/download?url=${encodeURIComponent(data.downloads.noWatermark)}&filename=${safeTitle}_nowatermark.mp4`;
      btnNoWm.style.display = 'flex';
      btnNoWm.onclick = () => window.showToast?.('Starting download: MP4 No Watermark...', 'success');
    }

    // Button: HD MP4
    const btnHd = document.getElementById('btnDownloadHd');
    if (btnHd) {
      if (data.downloads.hd) {
        btnHd.href = `/api/download?url=${encodeURIComponent(data.downloads.hd)}&filename=${safeTitle}_HD.mp4`;
        btnHd.style.display = 'flex';
        btnHd.onclick = () => window.showToast?.('Starting download: HD Quality...', 'success');
      } else {
        btnHd.style.display = 'none';
      }
    }

    // Button: With Watermark MP4
    const btnWm = document.getElementById('btnDownloadWm');
    if (btnWm) {
      if (data.downloads.watermark) {
        btnWm.href = `/api/download?url=${encodeURIComponent(data.downloads.watermark)}&filename=${safeTitle}_watermarked.mp4`;
        btnWm.style.display = 'flex';
      } else {
        btnWm.style.display = 'none';
      }
    }

    // Button: MP3 Audio
    const btnAudio = document.getElementById('btnDownloadAudio');
    if (btnAudio) {
      if (data.downloads.music) {
        btnAudio.href = `/api/download?url=${encodeURIComponent(data.downloads.music)}&filename=${safeTitle}_audio.mp3`;
        btnAudio.style.display = 'flex';
        btnAudio.onclick = () => window.showToast?.('Starting download: MP3 Audio...', 'success');
      } else {
        btnAudio.style.display = 'none';
      }
    }

    // Button: Cover Thumbnail
    const btnCover = document.getElementById('btnDownloadCover');
    if (btnCover && data.cover) {
      btnCover.href = `/api/download?url=${encodeURIComponent(data.cover)}&filename=${safeTitle}_cover.jpg`;
      btnCover.style.display = 'flex';
    }

    // Video In-page Preview Toggle
    const previewToggleBtn = document.getElementById('btnTogglePreview');
    if (previewToggleBtn && previewContainer) {
      previewContainer.innerHTML = '';
      previewContainer.style.display = 'none';
      previewToggleBtn.onclick = () => {
        if (previewContainer.style.display === 'none') {
          previewContainer.style.display = 'block';
          previewContainer.innerHTML = `
            <video controls autoplay playsinline style="width:100%; border-radius:12px; margin-top:10px; max-height:360px; background:#000;">
              <source src="${data.downloads.noWatermark || data.downloads.watermark}" type="video/mp4">
              Your browser does not support video playback.
            </video>
          `;
          previewToggleBtn.innerHTML = '✖ Hide Video Preview';
        } else {
          previewContainer.style.display = 'none';
          previewContainer.innerHTML = '';
          previewToggleBtn.innerHTML = '▶ Watch Video Preview';
        }
      };
    }

    // Photo Album / Carousel Slides
    const albumContainer = document.getElementById('photoAlbumContainer');
    const photoGrid = document.getElementById('photoGrid');
    if (albumContainer && photoGrid) {
      if (data.isImageAlbum && data.images && data.images.length > 0) {
        albumContainer.style.display = 'block';
        photoGrid.innerHTML = '';
        data.images.forEach((imgUrl, idx) => {
          const item = document.createElement('div');
          item.className = 'photo-item';
          item.innerHTML = `
            <img src="${imgUrl}" alt="TikTok Slide ${idx + 1}" loading="lazy">
            <a href="/api/download?url=${encodeURIComponent(imgUrl)}&filename=${safeTitle}_slide_${idx + 1}.jpg" class="photo-item-dl" download>
              ⬇ Slide ${idx + 1}
            </a>
          `;
          photoGrid.appendChild(item);
        });
      } else {
        albumContainer.style.display = 'none';
      }
    }
  }

  // Format numbers (e.g., 1400 -> 1.4K, 1500000 -> 1.5M)
  function formatNumber(num) {
    if (!num) return '0';
    if (num >= 1e6) return (num / 1e6).toFixed(1) + 'M';
    if (num >= 1e3) return (num / 1e3).toFixed(1) + 'K';
    return num.toLocaleString();
  }

  // Format Duration seconds to mm:ss
  function formatDuration(sec) {
    if (!sec) return '0:00';
    const mins = Math.floor(sec / 60);
    const secs = sec % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  }

  // Error handler
  function showError(msg) {
    if (errorMessage && errorBanner) {
      errorMessage.innerText = msg;
      errorBanner.classList.add('active');
    }
  }

  function hideError() {
    if (errorBanner) {
      errorBanner.classList.remove('active');
    }
  }

  // Local Storage History
  function saveToHistory(url, title, cover) {
    try {
      let history = JSON.parse(localStorage.getItem('tikflow_history') || '[]');
      // Filter out duplicate
      history = history.filter(item => item.url !== url);
      history.unshift({
        url,
        title: title || 'TikTok Video',
        cover: cover || '',
        date: new Date().toLocaleDateString()
      });
      // Keep last 10
      if (history.length > 10) history = history.slice(0, 10);
      localStorage.setItem('tikflow_history', JSON.stringify(history));
      renderHistory();
    } catch (e) {
      console.warn('Could not save history:', e);
    }
  }

  function renderHistory() {
    const historyList = document.getElementById('historyList');
    const historyWrap = document.getElementById('historySectionWrap');
    if (!historyList || !historyWrap) return;

    try {
      const history = JSON.parse(localStorage.getItem('tikflow_history') || '[]');
      if (history.length === 0) {
        historyWrap.style.display = 'none';
        return;
      }

      historyWrap.style.display = 'block';
      historyList.innerHTML = '';
      history.forEach(item => {
        const li = document.createElement('li');
        li.className = 'history-item';
        li.innerHTML = `
          <a href="#" class="history-link" title="${item.title}">
            🎥 ${item.title.substring(0, 50)}...
          </a>
          <button class="btn-paste" style="padding: 4px 10px; font-size: 0.75rem;">Re-download</button>
        `;

        li.querySelector('.history-link').addEventListener('click', (e) => {
          e.preventDefault();
          input.value = item.url;
          triggerAnalyze(item.url);
        });

        li.querySelector('button').addEventListener('click', () => {
          input.value = item.url;
          triggerAnalyze(item.url);
        });

        historyList.appendChild(li);
      });
    } catch (e) {
      console.warn('History read error:', e);
    }
  }

  // Clear history action
  const clearHistoryBtn = document.getElementById('clearHistoryBtn');
  if (clearHistoryBtn) {
    clearHistoryBtn.addEventListener('click', () => {
      localStorage.removeItem('tikflow_history');
      renderHistory();
      window.showToast?.('Download history cleared.');
    });
  }

  // Initial render of history
  renderHistory();
});
