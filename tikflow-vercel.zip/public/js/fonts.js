// TikFlow - Dynamic 50+ Google Fonts Engine

const GOOGLE_FONTS_CATALOG = [
  // Modern Sans-Serif
  { name: 'Inter', category: 'Sans-Serif', popular: true },
  { name: 'Poppins', category: 'Sans-Serif', popular: true },
  { name: 'Roboto', category: 'Sans-Serif', popular: true },
  { name: 'Outfit', category: 'Sans-Serif', popular: true },
  { name: 'Plus Jakarta Sans', category: 'Sans-Serif', popular: true },
  { name: 'Montserrat', category: 'Sans-Serif', popular: true },
  { name: 'Open Sans', category: 'Sans-Serif' },
  { name: 'Lato', category: 'Sans-Serif' },
  { name: 'Nunito', category: 'Sans-Serif' },
  { name: 'Rubik', category: 'Sans-Serif' },
  { name: 'Sora', category: 'Sans-Serif', popular: true },
  { name: 'DM Sans', category: 'Sans-Serif', popular: true },
  { name: 'Urbanist', category: 'Sans-Serif', popular: true },
  { name: 'Raleway', category: 'Sans-Serif' },
  { name: 'Manrope', category: 'Sans-Serif' },
  { name: 'Lexend', category: 'Sans-Serif' },
  { name: 'Space Grotesk', category: 'Sans-Serif', popular: true },
  { name: 'Syne', category: 'Sans-Serif', popular: true },
  { name: 'Work Sans', category: 'Sans-Serif' },
  { name: 'Figtree', category: 'Sans-Serif' },
  { name: 'Cabin', category: 'Sans-Serif' },

  // Viral & Aesthetic Display
  { name: 'Bebas Neue', category: 'Display', popular: true },
  { name: 'Oswald', category: 'Display', popular: true },
  { name: 'Anton', category: 'Display', popular: true },
  { name: 'Archivo Black', category: 'Display' },
  { name: 'Righteous', category: 'Display', popular: true },
  { name: 'Orbitron', category: 'Display', popular: true },
  { name: 'Russo One', category: 'Display' },
  { name: 'Audiowide', category: 'Display' },
  { name: 'Black Ops One', category: 'Display' },
  { name: 'Alfa Slab One', category: 'Display' },
  { name: 'Bungee', category: 'Display' },
  { name: 'Monoton', category: 'Display' },
  { name: 'Press Start 2P', category: 'Display' },

  // Handwritten & Artistic
  { name: 'Pacifico', category: 'Handwritten', popular: true },
  { name: 'Caveat', category: 'Handwritten', popular: true },
  { name: 'Lobster', category: 'Handwritten', popular: true },
  { name: 'Dancing Script', category: 'Handwritten' },
  { name: 'Satisfy', category: 'Handwritten' },
  { name: 'Kalam', category: 'Handwritten' },
  { name: 'Shadows Into Light', category: 'Handwritten' },
  { name: 'Great Vibes', category: 'Handwritten' },
  { name: 'Kaushan Script', category: 'Handwritten' },
  { name: 'Indie Flower', category: 'Handwritten' },
  { name: 'Permanent Marker', category: 'Handwritten', popular: true },

  // Luxury & Editorial Serif
  { name: 'Playfair Display', category: 'Serif', popular: true },
  { name: 'Merriweather', category: 'Serif' },
  { name: 'Cinzel', category: 'Serif', popular: true },
  { name: 'Cormorant Garamond', category: 'Serif' },
  { name: 'Lora', category: 'Serif' },
  { name: 'Prata', category: 'Serif' },
  { name: 'Bodoni Moda', category: 'Serif' },
  { name: 'DM Serif Display', category: 'Serif', popular: true },

  // Monospace / Cyber Tech
  { name: 'JetBrains Mono', category: 'Monospace', popular: true },
  { name: 'Fira Code', category: 'Monospace' },
  { name: 'Space Mono', category: 'Monospace' }
];

const loadedFonts = new Set();

function applyFont(fontName) {
  if (!fontName) return;
  
  // Format for Google Fonts CDN link
  if (!loadedFonts.has(fontName) && fontName !== 'system') {
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    const formatted = fontName.replace(/ /g, '+');
    link.href = `https://fonts.googleapis.com/css2?family=${formatted}:wght@400;600;700;800;900&display=swap`;
    document.head.appendChild(link);
    loadedFonts.add(fontName);
  }

  // Update root font variable
  if (fontName === 'system') {
    document.documentElement.style.setProperty(
      '--font-main',
      "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif"
    );
  } else {
    document.documentElement.style.setProperty(
      '--font-main',
      `'${fontName}', -apple-system, BlinkMacSystemFont, sans-serif`
    );
  }

  localStorage.setItem('tikflow_font', fontName);
  
  // Update active pill in font list
  document.querySelectorAll('.font-picker-item').forEach(el => {
    if (el.dataset.font === fontName) {
      el.classList.add('active');
    } else {
      el.classList.remove('active');
    }
  });

  const fontNameDisplay = document.getElementById('currentFontName');
  if (fontNameDisplay) {
    fontNameDisplay.innerText = fontName === 'system' ? 'System Default' : fontName;
  }
}

// Initialize saved font
(function initSavedFont() {
  const saved = localStorage.getItem('tikflow_font') || 'system';
  if (saved && saved !== 'system') {
    applyFont(saved);
  }
})();

// Render Font Switcher UI inside Modal
function initFontSwitcherUI() {
  const fontGrid = document.getElementById('fontCardsGrid');
  const searchInput = document.getElementById('fontSearchInput');
  const categoryPills = document.querySelectorAll('.font-cat-pill');
  if (!fontGrid) return;

  const currentFont = localStorage.getItem('tikflow_font') || 'system';

  function renderList(filterCategory = 'All', searchQuery = '') {
    fontGrid.innerHTML = '';

    // First card is always System Default
    const systemCard = document.createElement('div');
    systemCard.className = `font-picker-item ${currentFont === 'system' ? 'active' : ''}`;
    systemCard.dataset.font = 'system';
    systemCard.innerHTML = `
      <div class="font-item-header">
        <span class="font-name">System Default</span>
        <span class="font-badge">Native</span>
      </div>
      <div class="font-preview-sample" style="font-family: -apple-system, sans-serif;">
        Download TikTok Videos in HD
      </div>
    `;
    systemCard.addEventListener('click', () => {
      applyFont('system');
      window.showToast?.('Applied System Default Font');
    });

    if (filterCategory === 'All' || filterCategory === 'Sans-Serif') {
      if (!searchQuery || 'system default'.includes(searchQuery.toLowerCase())) {
        fontGrid.appendChild(systemCard);
      }
    }

    const filtered = GOOGLE_FONTS_CATALOG.filter(font => {
      const matchCat = filterCategory === 'All' || font.category === filterCategory;
      const matchSearch = !searchQuery || font.name.toLowerCase().includes(searchQuery.toLowerCase());
      return matchCat && matchSearch;
    });

    filtered.forEach(font => {
      const card = document.createElement('div');
      const isSelected = localStorage.getItem('tikflow_font') === font.name;
      card.className = `font-picker-item ${isSelected ? 'active' : ''}`;
      card.dataset.font = font.name;
      card.innerHTML = `
        <div class="font-item-header">
          <span class="font-name">${font.name}</span>
          <span class="font-cat-tag">${font.category}</span>
        </div>
        <div class="font-preview-sample font-preview-loadable" data-font="${font.name}">
          Download TikTok Videos in HD
        </div>
      `;

      card.addEventListener('click', () => {
        applyFont(font.name);
        window.showToast?.(`Applied font: ${font.name}`);
      });

      fontGrid.appendChild(card);
    });

    // Lazy load previews when visible
    lazyLoadFontPreviews();
  }

  // Pre-load font previews for visible items
  function lazyLoadFontPreviews() {
    const previewNodes = document.querySelectorAll('.font-preview-loadable');
    previewNodes.forEach(node => {
      const fName = node.dataset.font;
      if (fName && !loadedFonts.has(fName)) {
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = `https://fonts.googleapis.com/css2?family=${fName.replace(/ /g, '+')}:wght@700&text=Download+TikTok+Videos+in+HD&display=swap`;
        document.head.appendChild(link);
      }
      node.style.fontFamily = `'${fName}', sans-serif`;
    });
  }

  // Search filter
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      const activeCatBtn = document.querySelector('.font-cat-pill.active');
      const cat = activeCatBtn ? activeCatBtn.dataset.category : 'All';
      renderList(cat, e.target.value.trim());
    });
  }

  // Category pills
  categoryPills.forEach(pill => {
    pill.addEventListener('click', () => {
      categoryPills.forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      const search = searchInput ? searchInput.value.trim() : '';
      renderList(pill.dataset.category, search);
    });
  });

  renderList('All', '');
}

document.addEventListener('DOMContentLoaded', () => {
  initFontSwitcherUI();
});

window.applyFont = applyFont;
