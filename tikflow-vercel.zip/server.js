import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PUBLIC_DIR = path.join(__dirname, 'public');
const PORT = process.env.PORT || 3000;

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8'
};

const ROUTE_MAP = {
  '/': 'index.html',
  '/index.html': 'index.html',
  '/mp3-downloader': 'mp3-downloader.html',
  '/photo-downloader': 'photo-downloader.html',
  '/how-to-download': 'how-to-download.html',
  '/faq': 'faq.html',
  '/about': 'about.html',
  '/contact': 'contact.html',
  '/privacy-policy': 'privacy-policy.html',
  '/terms-of-service': 'terms.html',
  '/terms': 'terms.html',
  '/dmca': 'dmca.html',
  '/robots.txt': 'robots.txt'
};

const setCorsHeaders = (res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Requested-With');
};

const sendJson = (res, statusCode, data) => {
  setCorsHeaders(res);
  res.writeHead(statusCode, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(data));
};

const handleAnalyze = async (req, res, targetUrl) => {
  if (!targetUrl || typeof targetUrl !== 'string') {
    return sendJson(res, 400, { success: false, message: 'Please provide a valid TikTok video URL.' });
  }

  const cleanUrl = targetUrl.trim();
  const tiktokRegex = /(tiktok\.com|douyin\.com)/i;
  if (!tiktokRegex.test(cleanUrl)) {
    return sendJson(res, 400, {
      success: false,
      message: 'Invalid link. Please paste a valid TikTok video, photo, or music link.'
    });
  }

  try {
    const apiUrl = `https://www.tikwm.com/api/?url=${encodeURIComponent(cleanUrl)}&count=12&cursor=0&web=1&hd=1`;
    const response = await fetch(apiUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        'Accept': 'application/json'
      }
    });

    if (!response.ok) {
      return sendJson(res, 502, {
        success: false,
        message: 'TikWM service responded with an error. Please try again in a few moments.'
      });
    }

    const data = await response.json();

    if (data.code !== 0 || !data.data) {
      return sendJson(res, 422, {
        success: false,
        message: data.msg || 'Unable to fetch video. The video might be private, deleted, or regional-restricted.'
      });
    }

    const item = data.data;

    // Helper to format full URL
    const formatUrl = (u) => {
      if (!u) return null;
      if (u.startsWith('//')) return `https:${u}`;
      if (u.startsWith('/')) return `https://www.tikwm.com${u}`;
      return u;
    };

    const result = {
      success: true,
      id: item.id,
      title: item.title || 'TikTok Video',
      duration: item.duration || 0,
      createTime: item.create_time,
      cover: formatUrl(item.cover) || formatUrl(item.origin_cover),
      author: {
        id: item.author?.id,
        uniqueId: item.author?.unique_id || 'tiktok_user',
        nickname: item.author?.nickname || 'TikTok Creator',
        avatar: formatUrl(item.author?.avatar)
      },
      stats: {
        playCount: item.play_count || 0,
        diggCount: item.digg_count || 0,
        commentCount: item.comment_count || 0,
        shareCount: item.share_count || 0,
        downloadCount: item.download_count || 0
      },
      downloads: {
        noWatermark: formatUrl(item.play),
        watermark: formatUrl(item.wmplay),
        hd: formatUrl(item.hdplay),
        music: formatUrl(item.music),
        musicInfo: {
          title: item.music_info?.title || 'Original Sound',
          author: item.music_info?.author || '',
          album: item.music_info?.album || ''
        }
      },
      images: Array.isArray(item.images) ? item.images.map(img => formatUrl(img)) : null,
      isImageAlbum: Array.isArray(item.images) && item.images.length > 0
    };

    return sendJson(res, 200, result);
  } catch (error) {
    console.error('Error analyzing TikTok URL:', error);
    return sendJson(res, 500, {
      success: false,
      message: 'Failed to process request. Please check your internet connection and try again.'
    });
  }
};

const handleDownloadStream = async (req, res, targetUrl, fileName) => {
  if (!targetUrl) {
    res.writeHead(400, { 'Content-Type': 'text/plain' });
    return res.end('Target URL is required.');
  }

  try {
    const upstreamRes = await fetch(targetUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        'Referer': 'https://www.tiktok.com/'
      }
    });

    if (!upstreamRes.ok) {
      res.writeHead(upstreamRes.status, { 'Content-Type': 'text/plain' });
      return res.end('Failed to fetch media from CDN.');
    }

    const safeName = (fileName || 'tiktok_download').replace(/[^a-zA-Z0-9_\-\.]/g, '_');
    const contentType = upstreamRes.headers.get('content-type') || 'application/octet-stream';
    const contentLength = upstreamRes.headers.get('content-length');

    const headers = {
      'Content-Type': contentType,
      'Content-Disposition': `attachment; filename="${safeName}"`,
      'Access-Control-Allow-Origin': '*'
    };

    if (contentLength) {
      headers['Content-Length'] = contentLength;
    }

    res.writeHead(200, headers);

    const reader = upstreamRes.body.getReader();
    const streamNext = async () => {
      try {
        const { done, value } = await reader.read();
        if (done) {
          res.end();
          return;
        }
        res.write(value);
        streamNext();
      } catch (streamErr) {
        console.error('Stream error:', streamErr);
        res.end();
      }
    };

    streamNext();
  } catch (error) {
    console.error('Error in proxy stream:', error);
    res.writeHead(500, { 'Content-Type': 'text/plain' });
    res.end('Error streaming download.');
  }
};

const serveStaticFile = (filePath, res) => {
  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      // 404 handler - fallback to index or 404 message
      res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end(`<!DOCTYPE html>
<html>
<head><title>404 Not Found - TikFlow</title><style>body{font-family:sans-serif;background:#0d0e15;color:#fff;text-align:center;padding:50px 20px;}a{color:#00f2fe;text-decoration:none;}</style></head>
<body>
  <h1>404 - Page Not Found</h1>
  <p>The page you are looking for does not exist.</p>
  <p><a href="/">← Return to TikFlow Downloader</a></p>
</body>
</html>`);
      return;
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    res.writeHead(200, {
      'Content-Type': contentType,
      'Cache-Control': 'no-cache, no-store, must-revalidate'
    });

    const fileStream = fs.createReadStream(filePath);
    fileStream.pipe(res);
  });
};

const server = http.createServer(async (req, res) => {
  const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = parsedUrl.pathname;

  // Handle CORS Preflight
  if (req.method === 'OPTIONS') {
    setCorsHeaders(res);
    res.writeHead(204);
    return res.end();
  }

  // API: Analyze Video
  if (pathname === '/api/analyze') {
    if (req.method === 'GET') {
      const urlParam = parsedUrl.searchParams.get('url');
      return handleAnalyze(req, res, urlParam);
    } else if (req.method === 'POST') {
      let body = '';
      req.on('data', chunk => {
        body += chunk;
        if (body.length > 1e6) req.destroy();
      });
      req.on('end', () => {
        try {
          const parsed = JSON.parse(body || '{}');
          handleAnalyze(req, res, parsed.url);
        } catch {
          sendJson(res, 400, { success: false, message: 'Invalid JSON request payload.' });
        }
      });
      return;
    }
  }

  // API: Download stream proxy
  if (pathname === '/api/download') {
    const mediaUrl = parsedUrl.searchParams.get('url');
    const fileName = parsedUrl.searchParams.get('filename');
    return handleDownloadStream(req, res, mediaUrl, fileName);
  }

  // API: Contact Us Form Submit
  if (pathname === '/api/contact' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const data = JSON.parse(body || '{}');
        if (!data.email || !data.message) {
          return sendJson(res, 400, { success: false, message: 'Email and message are required.' });
        }
        return sendJson(res, 200, {
          success: true,
          message: 'Thank you! Your message has been received. Our team will review it and reply within 24-48 business hours.'
        });
      } catch {
        return sendJson(res, 400, { success: false, message: 'Invalid request body.' });
      }
    });
    return;
  }

  // Route mapping for clean URLs
  if (ROUTE_MAP[pathname]) {
    const mappedFile = path.join(PUBLIC_DIR, ROUTE_MAP[pathname]);
    return serveStaticFile(mappedFile, res);
  }

  // Static files in /public
  const safePath = path.normalize(pathname).replace(/^(\.\.[\/\\])+/, '');
  const filePath = path.join(PUBLIC_DIR, safePath);

  // Security check: ensure path is within PUBLIC_DIR
  if (!filePath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403, { 'Content-Type': 'text/plain' });
    return res.end('Access Denied');
  }

  serveStaticFile(filePath, res);
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 TikFlow TikTok Downloader server running at http://localhost:${PORT}`);
});
